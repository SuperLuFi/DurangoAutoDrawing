package com.durango.drawing

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val pickImageRequest = 1001
    private var sourceBitmap: Bitmap? = null
    private var pixelBitmap: Bitmap? = null
    private var gridSize = 26
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var sizeLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        status.text = "Pilih gambar untuk mulai."
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

        val title = TextView(this).apply {
            text = "Durango Auto Drawing"
            textSize = 23f
            setTextColor(Color.rgb(25, 25, 25))
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "MVP 0.1 • Pixel-art preview"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(12))
        }
        page.addView(subtitle, matchWrap())

        val pick = Button(this).apply {
            text = "Pilih gambar"
            setOnClickListener { openImagePicker() }
        }
        page.addView(pick, matchWrap())

        sizeLabel = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(12), 0, dp(4))
        }
        page.addView(sizeLabel, matchWrap())

        val slider = SeekBar(this).apply {
            max = 63
            progress = gridSize - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    gridSize = progress + 1
                    sizeLabel.text = "Grid: $gridSize × $gridSize"
                    if (fromUser) renderPixelArt()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        page.addView(slider, matchWrap())
        sizeLabel.text = "Grid: $gridSize × $gridSize"

        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
            contentDescription = "Pratinjau pixel art dengan grid"
        }
        val previewParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply {
            topMargin = dp(12)
            bottomMargin = dp(8)
        }
        page.addView(preview, previewParams)

        val generate = Button(this).apply {
            text = "Buat ulang pixel art"
            setOnClickListener { renderPixelArt() }
        }
        page.addView(generate, matchWrap())

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(8), 0, 0)
        }
        page.addView(status, matchWrap())

        setContentView(page)
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, pickImageRequest)
    }

    @Deprecated("Use Activity Result APIs in a later iteration")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickImageRequest || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.openInputStream(uri).use { stream ->
                sourceBitmap = BitmapFactory.decodeStream(stream)
            }
            if (sourceBitmap == null) {
                status.text = "Gambar tidak bisa dibaca. Coba file PNG/JPG lain."
                return
            }
            renderPixelArt()
        } catch (e: Exception) {
            status.text = "Gagal membuka gambar: ${e.localizedMessage ?: "error"}"
        }
    }

    private fun renderPixelArt() {
        val source = sourceBitmap
        if (source == null) {
            status.text = "Pilih gambar dulu."
            return
        }
        try {
            // Resize to a square grid. MVP version; later we will add crop/aspect controls.
            val small = Bitmap.createScaledBitmap(source, gridSize, gridSize, false)
            pixelBitmap = drawGrid(small)
            preview.setImageBitmap(pixelBitmap)
            status.text = "Siap: ${gridSize}×${gridSize} sel. Palet game dan auto-touch belum diaktifkan."
        } catch (e: Exception) {
            status.text = "Gagal memproses gambar: ${e.localizedMessage ?: "error"}"
        }
    }

    private fun drawGrid(bitmap: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(bitmap.width * 12, bitmap.height * 12, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawColor(Color.WHITE)

        for (y in 0 until bitmap.height) {
            for (x in 0 until bitmap.width) {
                paint.color = bitmap.getPixel(x, y)
                paint.style = Paint.Style.FILL
                canvas.drawRect(
                    (x * 12).toFloat(), (y * 12).toFloat(),
                    ((x + 1) * 12).toFloat(), ((y + 1) * 12).toFloat(), paint
                )
                paint.color = Color.argb(90, 30, 30, 30)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 0.5f
                canvas.drawRect(
                    (x * 12).toFloat(), (y * 12).toFloat(),
                    ((x + 1) * 12).toFloat(), ((y + 1) * 12).toFloat(), paint
                )
            }
        }
        return output
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
