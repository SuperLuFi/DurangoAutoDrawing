# Durango Auto Drawing — MVP 0.1

## What this first version does
- Opens an image from Android's file picker.
- Resizes it into a configurable square grid (1–64 cells per side).
- Shows a pixel-grid preview.

## Not implemented yet
- Official/verified Durango color palette.
- Preserve-aspect-ratio crop controls.
- Save/export drawing instructions.
- Canvas calibration.
- Accessibility-based touch automation.

## Build from an Android phone using GitHub Actions
1. Create a GitHub account if needed, then create a new **public or private repository** named `DurangoAutoDrawing`.
2. Extract this ZIP on your phone.
3. Upload the contents of this folder to the repository root (the `.github` folder must be included). GitHub's website may hide dot-folders in some upload flows; if so, use the browser's desktop-site mode or upload the ZIP and extract it in a cloud development environment.
4. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
5. Open the completed workflow run, download the `DurangoAutoDrawing-debug` artifact, and extract it.
6. Install `app-debug.apk` on your Android phone. If prompted, allow installation from the browser/file manager you used.

## Project settings
- Kotlin, Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17.
- compileSdk 35, targetSdk 35, minSdk 26.

This is a starter project, not a finished auto-drawing tool. Test the image preview first. Android touch automation will be a later phase and must be explicitly enabled by the user.
